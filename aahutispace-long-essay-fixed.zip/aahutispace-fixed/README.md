# aahutispace.

Fresh static version — no paid backend required.

## Put it on GitHub
1. Create a PUBLIC repository named `aahutispace`.
2. Upload `index.html`, `style.css`, and `script.js` directly to the ROOT.
3. Go to Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: `main` and folder: `/(root)`.
6. Save and wait for GitHub Pages to publish.

Do not upload only the ZIP. Upload the three files inside it.
