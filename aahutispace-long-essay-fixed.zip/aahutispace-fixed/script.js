const thoughts=[
"Maybe curiosity is just intelligence refusing to sit still.",
"We remember what mattered emotionally, not necessarily what happened most often.",
"You can know someone for years and still only know the version of them you met.",
"Your brain is constantly making predictions about a world it never gets to see completely.",
"Sometimes overthinking is just a very creative brain looking for certainty.",
"The person you are becoming is built from tiny decisions nobody else notices."
];
const output=document.getElementById("thoughtOutput");
document.getElementById("thoughtBtn").onclick=()=>{
 output.textContent="“"+thoughts[Math.floor(Math.random()*thoughts.length)]+"”";
 document.querySelector(".thought-box").scrollIntoView({behavior:"smooth",block:"center"});
};
const modal=document.getElementById("articleModal");
document.querySelectorAll(".card").forEach(card=>card.querySelector(".read").onclick=()=>{
 document.getElementById("modalTitle").textContent=card.dataset.title;
 document.getElementById("modalTag").textContent=card.dataset.tag;
 document.getElementById("modalText").innerHTML=card.dataset.text.split("\n\n").map(p=>p.trim()).filter(Boolean).map(p=>p.startsWith("CONCLUSION")||p.startsWith("KEY TAKEAWAYS")?`<h3>${p}</h3>`:`<p>${p}</p>`).join("");
 modal.showModal();
});
document.getElementById("closeModal").onclick=()=>modal.close();
modal.onclick=e=>{if(e.target===modal)modal.close()};
document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("dark");
